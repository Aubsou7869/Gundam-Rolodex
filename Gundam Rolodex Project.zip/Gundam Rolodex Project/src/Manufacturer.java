/*
Name: Aubrey Soule
Date: May 8,2026
Assignment: Gundam Rolodex - Final
Description: Represents a manufacturer of a Gundam (composition class).
*/

public class Manufacturer {

    private String name;
    private String origin;
    
    public String getName() {
    return name;
    }

    public String getOrigin() {
    return origin;
    }

    public Manufacturer(String name, String origin) {
        this.name = name;
        this.origin = origin;
    }

    @Override
    public String toString() {
        return name + " (" + origin + ")";
    }
}
