/*
Name: Aubrey Soule
Date: May 8,2026
Assignment: Gundam Rolodex - Final
Description: Base class representing a general Gundam.
*/

public abstract class Gundam implements Displayable {

    private String name;
    private String modelNumber;
    private String pilot;

    // Constructor
    public Gundam(String name, String modelNumber, String pilot) {
        this.name = name;
        this.modelNumber = modelNumber;
        this.pilot = pilot;
    }

    // Getters and Setters
    public String getName() {
        return name;
    }

    public String getModelNumber() {
        return modelNumber;
    }

    public String getPilot() {
        return pilot;
    }

    public void setPilot(String pilot) {
    this.pilot = pilot;
}

    public abstract void displayInfo();

    // toString
    @Override
    public String toString() {
        return "Name: " + name +
               "\nModel: " + modelNumber +
               "\nPilot: " + pilot;
    }
}