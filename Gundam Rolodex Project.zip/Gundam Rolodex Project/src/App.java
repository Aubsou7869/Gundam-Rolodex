/*
Name: Aubrey Soule
Date: May 8,2026
Assignment: Gundam Rolodex - Final
Description: Main application that allows the user to interact with the Gundam Rolodex.
*/


import java.util.Scanner;

public class App {

    public static void main(String[] args) {

        System.out.println("Aubrey Soule – Gundam Rolodex");
        System.out.println("=====================================");
        System.out.println("Welcome to Gundam Rolodex");
        System.out.println("\"War is not about who is right, but who is left.\"");
        System.out.println("Manage your Gundam collection below.\n");

        DatabaseManager.createTable();

        Scanner scanner = new Scanner(System.in);
        int choice;
        
        do {
            System.out.println("\nMenu:");
            System.out.println("1. Add Gundam");
            System.out.println("2. View All Gundams");
            System.out.println("3. Update Gundam");
            System.out.println("4. Delete Gundam");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            choice = scanner.nextInt();
            scanner.nextLine(); // clear buffer

            switch (choice) {

                case 1:
                    // ADD
                    System.out.print("Enter Name: ");
                    String name = scanner.nextLine();

                    System.out.print("Enter Model Number: ");
                    String model = scanner.nextLine();

                    System.out.print("Enter Pilot: ");
                    String pilot = scanner.nextLine();

                    System.out.print("Enter Type: ");
                    String type = scanner.nextLine();

                    System.out.print("Enter Weapon: ");
                    String weapon = scanner.nextLine();

                    System.out.print("Enter Manufacturer Name: ");
                    String manuName = scanner.nextLine();

                    System.out.print("Enter Manufacturer Origin: ");
                    String origin = scanner.nextLine();

                    Manufacturer m = new Manufacturer(manuName, origin);
                    CombatGundam newGundam = new CombatGundam(
                            name, model, pilot, type, weapon, m);

                    DatabaseManager.addGundam(newGundam);
                    System.out.println("Gundam added successfully!");
                    break;

                case 2:
                    // VIEW
                    DatabaseManager.viewGundams();
                    break;

                case 3:
                    // UPDATE
                    System.out.print("Enter ID to update: ");
                    int ID = scanner.nextInt();
                    scanner.nextLine();

                        System.out.print("Enter new Pilot: ");
                        String setPilot = scanner.nextLine();

                        System.out.print("Enter new Type: ");
                        String newType = scanner.nextLine();

                        System.out.print("Enter new Weapon: ");
                        String newWeapon = scanner.nextLine();

                        DatabaseManager.updateGundam(ID, setPilot, newType, newWeapon);
                        System.out.println("Gundam updated!");
                    break;

                case 4:
                    // DELETE
                    System.out.print("Enter index to delete: ");
                    int deleteIndex = scanner.nextInt();

                    DatabaseManager.deleteGundam(deleteIndex);
                    break;

                case 5:
                    System.out.println("Thank you for using Gundam Rolodex. Goodbye!");
                    break;

                default:
                    System.out.println("Invalid choice.");
            }

        } while (choice != 5);

        scanner.close();
    }
}