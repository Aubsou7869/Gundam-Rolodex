/*
Name: Aubrey Soule
Date: May 8,2026
Assignment: Gundam Rolodex - Final
Description: Interface that enforces display behavior.
*/

public interface Displayable {
    void displayInfo();
}