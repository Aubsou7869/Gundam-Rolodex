/*
Name: Aubrey Soule
Date: May 8,2026
Assignment: Gundam Rolodex - Final
Description: Handles SQLite database connection and CRUD operations.
*/

import java.sql.*;

public class DatabaseManager {

    private static final String URL = "jdbc:sqlite:gundam.db";

    // CREATE TABLE
    public static void createTable() {
        String sql = "CREATE TABLE IF NOT EXISTS gundams (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT," +
                "model TEXT," +
                "pilot TEXT," +
                "type TEXT," +
                "weapon TEXT," +
                "manufacturer TEXT," +
                "origin TEXT" +
                ");";

        try (Connection conn = DriverManager.getConnection(URL);
             Statement stmt = conn.createStatement()) {

            stmt.execute(sql);

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // CREATE 
    public static void addGundam(CombatGundam g) {
        String sql = "INSERT INTO gundams(name, model, pilot, type, weapon, manufacturer, origin) VALUES(?,?,?,?,?,?,?)";

        try (Connection conn = DriverManager.getConnection(URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, g.getName());
            pstmt.setString(2, g.getModelNumber());
            pstmt.setString(3, g.getPilot());
            pstmt.setString(4, g.getType());
            pstmt.setString(5, g.getWeapon());
            pstmt.setString(6, g.getManufacturer().getName());
            pstmt.setString(7, g.getManufacturer().getOrigin());

            pstmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // READ 
    public static void viewGundams() {
        String sql = "SELECT * FROM gundams";

        try (Connection conn = DriverManager.getConnection(URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                System.out.println("ID: " + rs.getInt("id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Model: " + rs.getString("model"));
                System.out.println("Pilot: " + rs.getString("pilot"));
                System.out.println("Type: " + rs.getString("type"));
                System.out.println("Weapon: " + rs.getString("weapon"));
                System.out.println("Manufacturer: " + rs.getString("manufacturer") +
                        " (" + rs.getString("origin") + ")");
                System.out.println("-----------------------------------");
            }

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    // UPDATE
    public static void updateGundam(int id, String pilot, String type, String weapon) {
    String sql = "UPDATE gundams SET pilot = ?, type = ?, weapon = ? WHERE id = ?";

    try (Connection conn = DriverManager.getConnection(URL);
         PreparedStatement pstmt = conn.prepareStatement(sql)) {

        pstmt.setString(1, pilot);
        pstmt.setString(2, type);
        pstmt.setString(3, weapon);
        pstmt.setInt(4, id);

        int rowsUpdated = pstmt.executeUpdate();

        if (rowsUpdated > 0) {
            System.out.println("Gundam updated successfully!");
        } else {
            System.out.println("No Gundam found with that ID.");
        }

    } catch (SQLException e) {
        System.out.println(e.getMessage());
    }
}

    // DELETE
    public static void deleteGundam(int id) {
        String sql = "DELETE FROM gundams WHERE id = ?";

        try (Connection conn = DriverManager.getConnection(URL);
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            pstmt.executeUpdate();

        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }
}