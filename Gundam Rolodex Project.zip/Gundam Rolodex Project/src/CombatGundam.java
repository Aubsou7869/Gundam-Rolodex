/*
Name: Aubrey Soule
Date: May 8,2026
Assignment: Gundam Rolodex - Final
Description: Derived class that extends Gundam and demonstrates inheritance and composition.
*/

public class CombatGundam extends Gundam {

    private String type;
    private String weapon;
    private Manufacturer manufacturer;

    public String getType() { return type; }
    public String getWeapon() { return weapon; }
    public Manufacturer getManufacturer() { return manufacturer; }

    public CombatGundam(String name, String modelNumber, String pilot,
                        String type, String weapon, Manufacturer manufacturer) {

        super(name, modelNumber, pilot);
        this.type = type;
        this.weapon = weapon;
        this.manufacturer = manufacturer;
    }

    public void setType(String type) {
        this.type = type;
    }

    public void setWeapon(String weapon) {
        this.weapon = weapon;
    }

    // toString override
   
   @Override
   
    public void displayInfo() {
        System.out.println("Name: " + getName());
        System.out.println("Model: " + getModelNumber());
        System.out.println("Pilot: " + getPilot());
        System.out.println("Type: " + getType());
        System.out.println("Weapon: " + getWeapon());
        System.out.println("Manufacturer: " + getManufacturer());
    }
}